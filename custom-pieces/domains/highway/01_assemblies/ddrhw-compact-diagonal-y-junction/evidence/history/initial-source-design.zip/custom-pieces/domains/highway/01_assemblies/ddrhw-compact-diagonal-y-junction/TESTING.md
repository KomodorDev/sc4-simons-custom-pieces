---
title: "DD RHW-4 compact diagonal Y-junction testing"
summary: "Reproduce the first source-layout checks, inspect native boundaries and clearance limits, and track the remaining physical and game implementation work."
audience: "Piece authors and reviewers"
document_type: "reference"
---

# DD RHW-4 compact diagonal Y-junction testing

<!-- ASSEMBLY TESTING LAYOUT: 1 -->

<!-- BEGIN DOCUMENT NAVIGATION -->
[1. Test scope](#1-test-scope) · [2. Test setup](#2-test-setup) · [3. Software checks](#3-software-checks) · [4. Game checks](#4-game-checks) · [5. Results and known issues](#5-results-and-known-issues) · [6. Design history](#6-design-history)
<!-- END DOCUMENT NAVIGATION -->

## 1. Test scope

This is an unregistered source-design experiment for the [compact diagonal Y-junction](README.md). The [brief](checks/design-brief.jsonc) owns the agreed six journeys and source parameters. Three standard DD RHW-4 ends each have two same-direction lanes on a 15 m upper deck and two opposing lanes on a 7.5 m lower deck. A is southwest, B is northwest, and C is east. A↔B and A↔C remain level; B→C and C→B each climb from 7.5 m to 15 m. Each journey has one lane. U-turns are excluded.

The current checks cover the supplied piecewise-linear source routes, all twelve native exterior lane contacts, direction and lane metadata, exact 3 m flat joins, every source segment's grade, sampled radius diagnostics, and all fifteen route pairs. A **grade** is height change divided by horizontal travel: 20% means rising 2 m while travelling 10 m horizontally. The existing 30% ceiling is experimental game geometry; it is not a real-road design standard.

The checks do not establish encoded game paths, final road surfaces, markings, barriers, supports, construction ownership, module cuts, resource identifiers, controller behavior, or operation in SimCity 4. No authoritative manual-observation record is created before a real registered candidate and its extracted journeys exist.

## 2. Test setup

Run commands from the repository root, with the [repository's Python dependencies](../../../../../README.md#2-prepare-python-and-run-the-tests) installed. The design and verification tools use NumPy, and the schematic renderer uses Pillow. Regenerating the source layout reads the included native measurement record; it does not need proprietary game archives or personal workstation paths. A later native build must validate its actual supported input archives separately.

Technical coordinates are east, north, and height in metres. Tile centres are `(16 × column, −16 × row)` m, and tile edges are 8 m from their centres. Native A and B axes satisfy `north − east = −8` m and `north + east = 8` m, respectively; C lies on `north = 0` m. Their common axis intersection is `(8, 0)` m. The native diagonal phases prevent treating an arbitrary common origin as an interchangeable socket frame.

The source schematic displays the southwest outside socket centre `(-32, -32)` m as X0, Y0. Thus display X is `(east + 32) / 16`, and display Y is `(north + 32) / 16`. Native socket centres occupy X0 through X6 and Y0 through Y4. Their context frame is 112 m × 80 m, including outside sockets. This is a drawing frame, not a claim about owned construction cells. The source road strips project partly into native socket cells and are deliberately not a final construction mask.

Only the first compatible native phase is produced. The [native audit](evidence/native-design-inputs.jsonc) explains the other diagonal-axis intersection parity and the current coverage limits. The brief does not require fitting three independently fixed prebuilt axes in every relative alignment. Establish any additional required variants from measured boundaries; produce another variant only after acceptance of the exact first candidate under the [shared alignment rule](../../../../docs/WORKFLOW_PIECE_CREATION.md#alignment-production-order).

## 3. Software checks

### 3.1 Regenerate and independently verify the source layout

1. Generate the six source routes and their source measurements:

   ```sh
   python3 -B custom-pieces/domains/highway/tools/ddrhw_y_geometry.py --output custom-pieces/domains/highway/01_assemblies/ddrhw-compact-diagonal-y-junction/evidence
   ```

2. Independently verify that output. This tool reconstructs native endpoints from the measured original donor routes and their poses; it does not import the geometry writer:

   ```sh
   python3 -B custom-pieces/domains/highway/tools/verify_ddrhw_y_design.py
   ```

3. Regenerate the source schematic and its provenance:

   ```sh
   python3 -B custom-pieces/domains/highway/tools/render_ddrhw_y_design.py --output custom-pieces/domains/highway/01_assemblies/ddrhw-compact-diagonal-y-junction/previews/source-schematic.png --evidence custom-pieces/domains/highway/01_assemblies/ddrhw-compact-diagonal-y-junction/evidence/source-schematic.jsonc
   ```

4. Run the focused source-design regression tests:

   ```sh
   python3 -B -m unittest discover -s custom-pieces/domains/highway/tests -p test_ddrhw_y_design.py -v
   ```

5. Check library documentation and the full repository test suites:

   ```sh
   python3 -B custom-pieces/scp.py docs-check
   python3 -B tools/run_tests.py
   ```

The geometry report binds the brief, native measurement record, and writer by SHA-256 fingerprints. A **fingerprint** identifies exact file bytes. The independent report also binds its verifier and the actual geometry report. Changed inputs require regeneration; a retained report does not verify a newer source.

### 3.2 Current source measurements

| Directed ramp | Horizontal length | Maximum source grade |
| --- | ---: | ---: |
| B → C | Approximately 88.202 m | Approximately 26.572% |
| C → B | Approximately 90.978 m | Approximately 25.761% |

Both ramps keep level approach sections before and after their height change. All twelve exterior native contacts preserve exact position, travel tangent, transport class, compatibility, lane class, and a flat 3 m joining section within a 1 nm numerical comparison tolerance. A **nanometre**, abbreviated nm, is one billionth of a metre. These are source comparisons; native physical model seams need their own check.

The [geometry report](evidence/design-geometry.jsonc) includes source polylines and writer measurements. Its gradient-based radius is diagnostic. The [independent report](evidence/source-verification.jsonc) uses circumcircles through adjacent route samples; its smallest sampled radius is approximately 29.862 m. Neither method proves the continuous radius of the underlying analytic curve.

### 3.3 Bounded source clearance and rejection controls

The independent checker calculates finite planar segment-to-segment distances and conservatively gates them with each segment's complete height interval. This covers points between the stored vertices of the supplied source polylines, within floating-point arithmetic precision. It is not merely a comparison of sampled vertex distances.

The declared vehicle envelope is 2.5 m wide × 3.8 m high. The provisional single-lane pavement is 6 m wide, and the provisional deck depth is 1 m. All fifteen route-pair checks pass those bounds. The smallest continuous horizontal vehicle separation is approximately 4.5275 m where the vertical vehicle intervals can meet, compared with the 2.5 m requirement. The smallest noncoplanar road/vehicle separation is approximately 5.4401 m, compared with the 4.25 m requirement. Coplanar adjacent road strips still need one coordinated pavement union; the checker does not accept duplicate pavement faces or establish barrier fit.

The verifier's three rejection controls detect a moved native endpoint, an interior grade spike, and coincident opposing climbing corridors. Eight focused regression tests additionally reject an actual zero-bulge ramp collision, a swapped lane class, a concealed height change in a flat route, and an incorrect native pose, and check analytic segment-distance controls. Their passing state establishes the stated source scope only.

The [workflow checkpoint](evidence/workflow-checkpoint.jsonc) records the actual command outcomes and exact candidate files. The full portable source suite passed with 2,223 reported tests and 92 explicit skip entries for unavailable native inputs or saved builds; these skips are listed separately from passed checks. All code and numeric inputs matched the working candidate; the two draft guides received a separate final link and navigation check after prose updates. An additional native-backed full run was stopped while verifying unchanged retained HSR models and did not complete; no pass is claimed for that run.

### 3.4 Native measurement and reuse limits

The [native measurement record](evidence/native-design-inputs.jsonc) contains the freshly decoded supported DD archive, controller fingerprints, donor resources, exact native routes and poses, twelve lane contacts, model measurements, and original continuation-rule checks. Orthogonal donor `57530000` and diagonal donor `57530900` have pavement approximately 1 mm above the nominal path height; donor `57530200` uses exact nominal pavement heights. The eventual joining meshes must preserve the actual donor datum, full cross-section, materials, UVs, and overhang behavior.

Existing orthogonal starter solution rows are already present in the original controller. The eight corresponding diagonal marker solution rows require the existing explicit insertion mechanism. Existing native-approach adapters are limited to exact reviewed owners; a new subject needs its own reviewed binding. Generic native continuation-template matches do not verify a new component's complete construction or native dragging.

No complete existing piece was established as the required 2→1+1 lane split or DD lower-to-upper link. Reuse is currently limited to source mechanisms and measured native profiles. The [candidate functions](README.md#2-pieces) still need complete physical interfaces and demonstrably useful safe cuts before registration.

## 4. Game checks

Game checks are pending a real registered, independently verified, and deliberately installed candidate. Do not place this source draft or treat its picture as a game test. After component resources exist, extract their exact connection cases and initialize the authoritative observation record through the owning highway workflow and the [shared testing procedure](../../../../docs/TESTING.md).

The eventual cases must cover every component's four proper construction rotations; one assembly menu button with Tab and Shift+Tab selection; fresh placement; prebuilt native approaches and supported drawing outward; all six directed journeys; Route Query and moving cars as separate observations; heights and shadows; redraw; demolition; and save/reload. Document any restart or fresh-placement requirement from the actual resource change. Additional required grid phases remain separate cases with their staged production boundary.

## 5. Results and known issues

**Current stage: checked source-route design.** The source generator and independent verifier pass for the first measured phase. No complete physical mesh, owned-tile partition, saved game-resource build, installation, or human game result exists for this subject.

Remaining work is concrete: preserve measured native pavement collars and markings; construct coordinated pavement unions, deck bodies, barriers, and supports; check complete physical clearance and overhang; choose useful module cuts with one owner per city tile; check runtime addresses; allocate and register only the justified types; implement elevated active paths with `UseElevation=1`; verify actual saved resources in all four rotations; extract connectors; and generate the six canonical compiled-model views and final menu package. The first corridor calculation supplies evidence for that work, rather than completing it.

The initial partition review keeps a native joining region's two decks and its split or merge together until a complete physical cut is proved. Coplanar adjacent ribbons need a shared pavement union, and independently placing components over the same city tile can replace an earlier component's routes. The complete world geometry must therefore precede the final ownership map. Proposed future uses and the three native extension points are recorded in [Pieces](README.md#2-pieces); all internal replacement interfaces and available surrounding construction space remain conditional on that physical proof.

The centreline bounds are 80 m east–west × 70.4 m north–south. Unclipped provisional 6 m strips occupy an illustrative 6 × 5 tile rectangle, including overlap into native socket cells. Actual native 16 m deck profiles, barriers, supports, clipping, and construction ownership can change the required footprint. This is not a proven minimum.

## 6. Design history

The functional brief was agreed on 2026-11-03 after clarifying the compass directions and distinguishing the flat A split from the two height-changing B↔C journeys. The stem is southwest, the diagonal branch is northwest, and the orthogonal branch is east. This gives 90° A↔B turns and 45° A↔C and B↔C turns.

The first native-grid investigation established that the common axis intersection must use a legal native phase; `(8, 0)` m is used here. A three-ray intersection arbitrarily placed at `(0, 0)` m would not preserve the measured native phases.

A private compaction experiment shortened the C approach by one tile. It reduced the provisional road/vehicle margin to approximately 0.065 m under the earlier 0.8 m deck-depth experiment. The retained first candidate keeps C one tile farther out, uses a stronger 1 m depth bound, and leaves more space for the actual physical-model investigation. This is a same-alignment parameter study, not a delivered second alignment or an optimality claim.
