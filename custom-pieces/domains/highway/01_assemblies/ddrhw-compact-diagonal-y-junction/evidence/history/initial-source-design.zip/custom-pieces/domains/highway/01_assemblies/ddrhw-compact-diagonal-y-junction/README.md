---
title: "DD RHW-4 — Compact Y-Junction — Diagonal Stem"
summary: "Develop a compact three-arm double-decker highway junction with one lane per journey and two separate height-changing branch connections."
audience: "Piece authors and reviewers"
document_type: "guide"
---

# DD RHW-4 — Compact Y-Junction — Diagonal Stem

<!-- BEGIN DOCUMENT NAVIGATION -->
[1. Views](#1-views) · [2. Pieces](#2-pieces) · [3. Placements](#3-placements) · [4. Connection matrix](#4-connection-matrix)
<!-- END DOCUMENT NAVIGATION -->

[Testing ↗ (separate document)](TESTING.md)

**Source-design draft.** This is the first measured layout for a modular blueprint: a junction assembled from reusable component pieces. It is not yet registered or selectable in the game. The [design brief](checks/design-brief.jsonc) records the agreed directions, lane counts, and engineering limits. [TESTING.md](TESTING.md) records the reproducible checks and their limits.

The southwest stem is **A**, the northwest diagonal branch is **B**, and the east orthogonal branch is **C**. **Orthogonal** means aligned with a city-grid edge. Each external connection is standard DD RHW-4: two lanes on a lower deck at 7.5 m and two opposing lanes on an upper deck at 15 m. A's upper lanes split into one lane toward B and one toward C. Their lower return routes join side by side into A's two lanes. One additional lane connects B to C, and another connects C to B; both rise from the lower deck to the upper deck.

The intended completed assembly has one menu button. **Tab** selects its next component, **Shift+Tab** selects the previous component, and each click places one component. No menu resource or game-piece identifier has been allocated at this source-design stage.

## 1. Views

![Measured source schematic of the southwest stem, northwest branch, east branch, and two separated climbing connections](previews/source-schematic.png)

This drawing shows the measured traffic routes. Grey bands show provisional 6 m road corridors; the outlined A, B, and C cells show the external native sockets. Upper and lower flat routes overlap in the top view, so lower routes use dashed strokes and opposite arrows. The small graph shows height along each climbing lane. The six compiled-model views will follow the independently verified component build.

One grid square is 16 m × 16 m. X increases east, and Y increases north. The displayed 7 × 5 context frame includes the outside native sockets; it is not an owned construction footprint. Actual pavement widths, native profiles, barriers, supports, and tile ownership still need their physical-model checks.

## 2. Pieces

No retained complete piece has been established as an exact replacement for the following functions. Existing slip pieces retain two through lanes and add another lane; this layout instead separates the original two lanes into one lane per destination. Existing low-level native readers, source-curve helpers, resource compilers, and connector tooling remain available for the implementation.

| Candidate reusable function | Purpose | Required next check |
| --- | --- | --- |
| Native DD terminal with two branches | Preserve both native lanes on each deck while separating them into individual routes. | Complete native pavement profiles, markings, complementary flow arrangements, and safe tile cuts. |
| Paired flat curve | Carry opposing A↔B or A↔C journeys on their existing decks. | Coplanar surface unions, barriers, supports, and complete reusable joining profiles. |
| Single-lane lower-to-upper connection | Carry B→C or C→B in a separate physical corridor. | Actual deck solids, barriers, full vehicle clearance, and useful interfaces. |

These are functional candidates, rather than a frozen part count. Routes and physical geometry sharing a city tile must have one construction owner. The physical checks may therefore require a coordinated component containing more than one candidate function.

Proposed reuse extends beyond these three placements: a two-lane terminal could feed two single-lane connector chains in another fork; a paired flat curve could connect matching stacked single-lane interfaces in another branch layout; and a lower-to-upper link could transfer traffic between separate DD highways. Each proposal requires complete physical interface checks and any missing adapters. No currently registered interchangeable counterpart is claimed. The three external standard DD sockets are the intended extension points for longer native highway approaches; actual native dragging remains a later game check.

## 3. Placements

The first design uses a native-grid-consistent axis intersection at technical coordinates `(east, north) = (8, 0)` m. Technical tile columns increase east, and rows increase south; their centres are `(16 × column, −16 × row)` m. The display uses the southwest socket cell centre as X0, Y0. See [the complete coordinate definition](TESTING.md#2-test-setup).

| Outside native socket | Display position | Technical cell `(column, row)` | Native donor | Clockwise native pose |
| --- | --- | --- | --- | --- |
| A, southwest stem | X0, Y0 | `(-2, 2)` | `57530900` | 0° |
| B, northwest diagonal branch | X0, Y4 | `(-2, -2)` | `57530900` | 270° |
| C, east orthogonal branch | X6, Y2 | `(4, 0)` | `57530000` | 270° |

These are native socket positions, not clickable component placement instructions. Stable P-labels, component rotations, cursor reference cells, and a construction sequence follow the physical ownership partition and registration. No other relative grid alignment is supplied by this first design.

## 4. Connection matrix

The following table describes the six intended journeys. Each current source route has independently checked native endpoints, flat joining sections, permitted height changes, and bounded route clearance. Saved game resources, Route Query, and visible travel remain unverified.

| From | To | Lanes | Entry height | Exit height |
| --- | --- | ---: | ---: | ---: |
| A | B | 1 | 15 m | 15 m |
| B | A | 1 | 7.5 m | 7.5 m |
| A | C | 1 | 15 m | 15 m |
| C | A | 1 | 7.5 m | 7.5 m |
| B | C | 1 | 7.5 m | 15 m |
| C | B | 1 | 7.5 m | 15 m |

U-turns A→A, B→B, and C→C are excluded. Each native exterior lane is used once by this source arrangement. This table is the agreed design and checked source-route scope; generated saved-resource connection records will replace it only after real component resources exist.
